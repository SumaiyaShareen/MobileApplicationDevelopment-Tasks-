import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Animated,
  StyleSheet,
  StatusBar,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Screen 1
function OnboardingScreen1({ navigation }) {
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
  }, []);

  return (
    <LinearGradient colors={['#4facfe', '#00f2fe']} style={styles.screen}>
      <StatusBar barStyle="light-content" />
      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <MaterialIcons name="emoji-emotions" size={120} color="#fff" />
        <Text style={styles.title}>Welcome to Snack App</Text>
        <Text style={styles.description}>
          Explore endless possibilities with our intuitive and powerful app.
        </Text>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Screen2')}
        >
          <Text style={styles.buttonText}>Next</Text>
        </TouchableOpacity>
      </Animated.View>
    </LinearGradient>
  );
}

// Screen 2
function OnboardingScreen2({ navigation }) {
  const slideAnim = useRef(new Animated.Value(-300)).current;

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: 0,
      friction: 6,
      useNativeDriver: true,
    }).start();
  }, []);

  return (
    <LinearGradient colors={['#43e97b', '#38f9d7']} style={styles.screen}>
      <Animated.View style={[styles.content, { transform: [{ translateY: slideAnim }] }]}>
        <MaterialIcons name="touch-app" size={120} color="#fff" />
        <Text style={styles.title}>Easy to Use</Text>
        <Text style={styles.description}>
          Simple, clean design crafted for the best user experience.
        </Text>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Screen3')}
        >
          <Text style={styles.buttonText}>Next</Text>
        </TouchableOpacity>
      </Animated.View>
    </LinearGradient>
  );
}

// Screen 3 (Final)
function OnboardingScreen3() {
  const scaleAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      friction: 4,
      useNativeDriver: true,
    }).start();
  }, []);

  const handleGetStarted = () => {
    alert('Welcome aboard! 🚀');
  };

  return (
    <LinearGradient colors={['#fa709a', '#fee140']} style={styles.screen}>
      <Animated.View style={[styles.content, { transform: [{ scale: scaleAnim }] }]}>
        <MaterialIcons name="rocket-launch" size={120} color="#fff" />
        <Text style={styles.title}>Get Started Now</Text>
        <Text style={styles.description}>
          Join millions of users on an exciting journey!
        </Text>
        <TouchableOpacity
          style={[styles.button, styles.getStartedButton]}
          onPress={handleGetStarted}
        >
          <Text style={styles.buttonText}>Get Started</Text>
        </TouchableOpacity>
      </Animated.View>
    </LinearGradient>
  );
}

// Navigation Stack
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen name="Screen1" component={OnboardingScreen1} />
        <Stack.Screen name="Screen2" component={OnboardingScreen2} />
        <Stack.Screen name="Screen3" component={OnboardingScreen3} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#fff',
    marginVertical: 10,
  },
  description: {
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 30,
  },
  button: {
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    paddingHorizontal: 40,
    borderRadius: 25,
  },
  getStartedButton: {
    backgroundColor: '#2196f3',
  },
  buttonText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
  },
});
