import React, { useState, useEffect } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import * as ScreenOrientation from "expo-screen-orientation";

export default function App() {
  const [orientation, setOrientation] = useState("Portrait");
  const [isLocked, setIsLocked] = useState(false);

  // Function to get the current orientation
  const getCurrentOrientation = async () => {
    const currentOrientation = await ScreenOrientation.getOrientationAsync();
    if (
      currentOrientation === ScreenOrientation.Orientation.PORTRAIT_UP ||
      currentOrientation === ScreenOrientation.Orientation.PORTRAIT_DOWN
    ) {
      setOrientation("Portrait");
    } else {
      setOrientation("Landscape");
    }
  };

  useEffect(() => {
    getCurrentOrientation();
  }, []);

  // Function to switch between orientations
  const toggleScreenOrientation = async () => {
    if (isLocked) return; // Do nothing if locked

    if (orientation === "Portrait") {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
      setOrientation("Landscape");
    } else {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
      setOrientation("Portrait");
    }
  };

  // Function to lock the current orientation
  const lockScreen = async () => {
    if (orientation === "Portrait") {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    } else {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
    }
    setIsLocked(true);
  };

  // Function to unlock the screen
  const unlockScreen = async () => {
    await ScreenOrientation.unlockAsync();
    setIsLocked(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Current View: {orientation}</Text>

      <TouchableOpacity
        style={[styles.button, styles.switchButton]}
        onPress={toggleScreenOrientation}
      >
        <Text style={styles.buttonText}>
          Switch to {orientation === "Portrait" ? "Landscape" : "Portrait"}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.button, styles.lockButton, isLocked && styles.disabledButton]}
        onPress={lockScreen}
        disabled={isLocked}
      >
        <Text style={[styles.buttonText, isLocked && styles.disabledText]}>
          Lock {orientation} Mode
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.button, styles.unlockButton, !isLocked && styles.disabledButton]}
        onPress={unlockScreen}
        disabled={!isLocked}
      >
        <Text style={[styles.buttonText, !isLocked && styles.disabledText]}>
          Unlock Screen
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1E1E1E",
  },
  text: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 20,
  },
  button: {
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 30,
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowOffset: { width: 2, height: 4 },
    shadowRadius: 5,
    elevation: 5,
    marginVertical: 10,
  },
  switchButton: {
    backgroundColor: "#FF9800",
  },
  lockButton: {
    backgroundColor: "#E53935",
  },
  unlockButton: {
    backgroundColor: "#43A047",
  },
  disabledButton: {
    backgroundColor: "#555",
  },
  buttonText: {
    color: "#FFF",
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
  },
  disabledText: {
    color: "#BBB",
  },
});
