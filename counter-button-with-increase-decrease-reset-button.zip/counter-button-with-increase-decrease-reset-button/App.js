import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

export default function App() {
  const [count, setCount] = useState(0);

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>🔢 Counter App</Text>

      {/* Display Count */}
      <Text style={styles.count}>{count}</Text>

      {/* Buttons Row */}
      <View style={styles.buttonRow}>
        <TouchableOpacity style={[styles.button, styles.increase]} onPress={() => setCount(count + 1)}>
          <Text style={styles.buttonText}>+ Increase</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.button, styles.decrease]} onPress={() => setCount(count - 1)}>
          <Text style={styles.buttonText}>- Decrease</Text>
        </TouchableOpacity>
      </View>

      {/* Reset Button */}
      <TouchableOpacity style={[styles.button, styles.reset]} onPress={() => setCount(0)}>
        <Text style={styles.buttonText}>🔄 Reset</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e1e1e",
    padding: 20,
    paddingTop: 50,
    alignItems: "center",
    justifyContent: "center",
  },
  heading: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#fff",
    marginBottom: 20,
  },
  count: {
    fontSize: 50,
    fontWeight: "bold",
    color: "#4CAF50",
    marginVertical: 20,
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "center",
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    margin: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  increase: {
    backgroundColor: "#4CAF50",
  },
  decrease: {
    backgroundColor: "#FF3D00",
  },
  reset: {
    backgroundColor: "#FF9800",
    width: "60%",
  },
  buttonText: {
    fontSize: 18,
    color: "#fff",
    fontWeight: "bold",
  },
});
