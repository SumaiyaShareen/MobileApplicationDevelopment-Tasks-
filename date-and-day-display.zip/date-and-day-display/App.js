import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet } from "react-native";

export default function App() {
  const [currentDate, setCurrentDate] = useState("");
  const [currentDay, setCurrentDay] = useState("");

  useEffect(() => {
    const date = new Date();
    
    // Format Date (DD-MM-YYYY)
    const formattedDate = date.toLocaleDateString("en-GB");

    // Get Day Name
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const dayName = days[date.getDay()];

    // Set State
    setCurrentDate(formattedDate);
    setCurrentDay(dayName);
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>📅 Today's Date & Day</Text>
      <Text style={styles.date}>{currentDate}</Text>
      <Text style={styles.day}>{currentDay}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e1e1e",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  heading: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#fff",
    marginBottom: 20,
  },
  date: {
    fontSize: 40,
    fontWeight: "bold",
    color: "#4CAF50",
    marginBottom: 10,
  },
  day: {
    fontSize: 35,
    fontWeight: "bold",
    color: "#FFEB3B",
  },
});
