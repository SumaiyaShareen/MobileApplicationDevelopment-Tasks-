import React, { useState } from 'react';
import { View, TextInput, Text, TouchableOpacity, StyleSheet, Alert, Switch } from 'react-native';

export default function App() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false);

  const handleSubmit = () => {
    if (fullName && email && password) {
      Alert.alert('Registration Successful', `Welcome, ${fullName}!`);
    } else {
      Alert.alert('Error', 'Please fill all fields');
    }
  };

  const toggleSwitch = () => setIsDarkMode(previousState => !previousState);

  return (
    <View style={[styles.container, { backgroundColor: isDarkMode ? '#121212' : '#f0f2f5' }]}>
      
      {/* Header with Dark Mode Toggle */}
      <View style={styles.headerContainer}>
        <Text style={[styles.header, { color: isDarkMode ? '#fff' : '#333' }]}>Create Your Account</Text>
        
        {/* Dark Mode Toggle with a stylish design */}
        <View style={[styles.switchContainer, { backgroundColor: isDarkMode ? '#333' : '#fff' }]}>
          <Switch
            value={isDarkMode}
            onValueChange={toggleSwitch}
            thumbColor={isDarkMode ? '#ffcc00' : '#008000'}  // Custom thumb color
            trackColor={{ false: '#767577', true: '#81b0ff' }}  // Smooth track color
          />
        </View>
      </View>

      <TextInput
        style={[styles.input, { backgroundColor: isDarkMode ? '#333' : '#fff', color: isDarkMode ? '#fff' : '#333' }]}
        placeholder="Full Name"
        placeholderTextColor={isDarkMode ? '#bbb' : '#888'}
        value={fullName}
        onChangeText={setFullName}
      />
      
      <TextInput
        style={[styles.input, { backgroundColor: isDarkMode ? '#333' : '#fff', color: isDarkMode ? '#fff' : '#333' }]}
        placeholder="Email Address"
        placeholderTextColor={isDarkMode ? '#bbb' : '#888'}
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />
      
      <TextInput
        style={[styles.input, { backgroundColor: isDarkMode ? '#333' : '#fff', color: isDarkMode ? '#fff' : '#333' }]}
        placeholder="Password"
        placeholderTextColor={isDarkMode ? '#bbb' : '#888'}
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      
      <TouchableOpacity style={[styles.button, { backgroundColor: isDarkMode ? '#3b5998' : '#3b5998' }]} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Submit</Text>
      </TouchableOpacity>
      
      <Text style={[styles.footer, { color: isDarkMode ? '#bbb' : '#888' }]}>By signing up, you agree to our Terms & Privacy Policy</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 35,
  },
  headerContainer: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    paddingHorizontal: 10,
  },
  switchContainer: {
    borderRadius: 30, // Round the switch container
    padding: 5,
    borderWidth: 2,
    borderColor: '#ddd',
    alignItems: 'center',
  },
  input: {
    width: '100%',
    height: 55,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 30,
    paddingLeft: 20,
    marginBottom: 18,
    fontSize: 16,
  },
  button: {
    width: '100%',
    height: 55,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
    elevation: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  footer: {
    fontSize: 12,
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 15,
  },
});
