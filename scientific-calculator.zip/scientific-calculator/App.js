import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import * as math from "mathjs";

export default function App() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");

  const handlePress = (value) => {
    if (value === "C") {
      setInput("");
      setResult("");
    } else if (value === "DEL") {
      setInput(input.slice(0, -1));
    } else if (value === "=") {
      try {
        let expression = input
          .replace(/π/g, `(${Math.PI})`) // Replace π with actual value
          .replace(/e/g, `(${Math.E})`) // Replace e with actual value
          .replace(/√/g, "sqrt") // Replace √ with sqrt function
          .replace(/log\(/g, "log10(") // Convert log(x) to log10(x)
          .replace(/ln\(/g, "log(") // Convert ln(x) to natural log
          .replace(/sin\(/g, "sin(")
          .replace(/cos\(/g, "cos(")
          .replace(/tan\(/g, "tan(");

        // Auto-close missing parentheses
        const openParens = (expression.match(/\(/g) || []).length;
        const closeParens = (expression.match(/\)/g) || []).length;
        expression += ")".repeat(openParens - closeParens);

        setResult(math.evaluate(expression).toString());
      } catch (error) {
        setResult("Error");
      }
    } else {
      setInput(input + value);
    }
  };

  const buttons = [
    ["C", "DEL", "π", "e"],
    ["sin(", "cos(", "tan(", "√("],
    ["log(", "ln(", "^", "/"],
    ["7", "8", "9", "*"],
    ["4", "5", "6", "-"],
    ["1", "2", "3", "+"],
    ["0", ".", "=", ""],
  ];

  return (
    <View style={styles.container}>
      {/* Display Screen */}
      <View style={styles.displayContainer}>
        <Text style={styles.inputText}>{input || "0"}</Text>
        <Text style={styles.resultText}>{result}</Text>
      </View>

      {/* Calculator Buttons */}
      <View style={styles.buttonContainer}>
        {buttons.map((row, rowIndex) => (
          <View key={rowIndex} style={styles.row}>
            {row.map((button) => (
              <TouchableOpacity
                key={button}
                style={[
                  styles.button,
                  isOperator(button) && styles.operatorButton,
                  button === "=" && styles.equalButton,
                ]}
                onPress={() => handlePress(button)}
              >
                <Text style={styles.buttonText}>{button}</Text>
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

const isOperator = (value) => {
  return ["+", "-", "*", "/", "π", "e", "sin(", "cos(", "tan(", "√(", "log(", "ln(", "^"].includes(value);
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e1e1e",
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 50,
  },
  displayContainer: {
    width: "90%",
    backgroundColor: "#333",
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    alignItems: "flex-end",
  },
  inputText: {
    fontSize: 28,
    color: "#FFF",
    textAlign: "right",
  },
  resultText: {
    fontSize: 26,
    color: "#FF9800",
    textAlign: "right",
    marginTop: 5,
  },
  buttonContainer: {
    width: "95%",
    flexWrap: "wrap",
    flexDirection: "column",
    justifyContent: "center",
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
  },
  button: {
    backgroundColor: "#444",
    width: 70,
    height: 70,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 12,
  },
  operatorButton: {
    backgroundColor: "#FF9800",
  },
  equalButton: {
    backgroundColor: "#4CAF50",
  },
  buttonText: {
    fontSize: 22,
    color: "#FFF",
    fontWeight: "bold",
  },
});
