import React, { useEffect, useRef } from "react";
import { View, Text, Animated, StyleSheet } from "react-native";

export default function App() {
  const letters = "HELLO WORLD".split(""); // Split into individual letters
  const animations = useRef(letters.map(() => new Animated.Value(0))).current;

  useEffect(() => {
    const animationsSequence = letters.map((_, index) => 
      Animated.timing(animations[index], {
        toValue: 1,
        duration: 300, // Each letter appears after 300ms
        delay: index * 300,
        useNativeDriver: true,
      })
    );

    Animated.stagger(150, animationsSequence).start();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.textContainer}>
        {letters.map((letter, index) => (
          <Animated.Text
            key={index}
            style={[
              styles.text,
              { opacity: animations[index], transform: [{ translateY: animations[index].interpolate({
                  inputRange: [0, 1],
                  outputRange: [20, 0], // Moves from below to original position
                })
              }] }
            ]}
          >
            {letter}
          </Animated.Text>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1e1e1e",
  },
  textContainer: {
    flexDirection: "row",
  },
  text: {
    fontSize: 40,
    fontWeight: "bold",
    color: "#4CAF50",
    marginHorizontal: 5,
  },
});
