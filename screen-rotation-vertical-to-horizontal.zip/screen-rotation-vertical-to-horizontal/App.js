import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import * as ScreenOrientation from "expo-screen-orientation";

export default function App() {
  const [isHorizontal, setIsHorizontal] = useState(false);

  // Function to toggle screen orientation
  const toggleScreenOrientation = async () => {
    if (isHorizontal) {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    } else {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
    }
    setIsHorizontal(!isHorizontal);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>
        Current View: {isHorizontal ? "Horizontal" : "Vertical"}
      </Text>
      <TouchableOpacity style={styles.button} onPress={toggleScreenOrientation}>
        <Text style={styles.buttonText}>
          Switch to {isHorizontal ? "Vertical" : "Horizontal"} View
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1e3c72",
  },
  text: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#fff",
  },
  button: {
    paddingVertical: 15,
    paddingHorizontal: 30,
    backgroundColor: "#ff6b6b",
    borderRadius: 25,
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowOffset: { width: 3, height: 3 },
    shadowRadius: 5,
    elevation: 5,
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
});
